import random
import os
import time

# --- Configurações de Performance ---
Settings.MoveMouseDelay = 0
Settings.ClickDelay = 0
Settings.ObserveScanRate = 60 
HUNT_MODE = "explorer"

def get_documents_dir():
    home = os.path.expanduser("~")
    cfg = os.path.join(home, ".config", "user-dirs.dirs")
    if os.path.exists(cfg):
        try:
            f = open(cfg, "r")
            for line in f:
                line = line.strip()
                if line.startswith("XDG_DOCUMENTS_DIR"):
                    val = line.split("=", 1)[1].strip().strip('"')
                    val = val.replace("$HOME", home).replace("${HOME}", home)
                    path = os.path.normpath(val)
                    if os.path.isdir(path):
                        f.close()
                        return path
            f.close()
        except: pass
    fallback = os.path.join(home, "Documents")
    return fallback if os.path.isdir(fallback) else home

# --- Pastas e Caminhos ---
DOCS_DIR = get_documents_dir()
IMG_DIR = os.path.join(DOCS_DIR, "B34R")
WPT_DIR = os.path.join(IMG_DIR, "WPT")

addImagePath(IMG_DIR)
addImagePath(WPT_DIR)

# --- Definições de Regiões ---
regMonstros = Region(1553,36,201,153)
regWpt      = Region(1745,50,173,182)
regRope     = Region(710,843,16,10)
regShovel   = Region(678,841,15,15)
regUse      = Region(852,439,28,26)

# --- Parâmetros ---
WAYPOINTS = [
	{"wpt": 1, "mode": "walk"},
	{"wpt": 2, "mode": "walk"},
	{"wpt": 3, "mode": "walk"},
	{"wpt": 4, "mode": "walk"},
	{"wpt": 5, "mode": "walk"},
	{"wpt": 6, "mode": "walk"},
	{"wpt": 7, "mode": "walk"},
	{"wpt": 8, "mode": "walk"},
	{"wpt": 5, "mode": "walk"},
	{"wpt": 4, "mode": "walk"},
	{"wpt": 3, "mode": "walk"},
	{"wpt": 9, "mode": "walk"}
]

# Note: Para busca EXATA, usamos 0.99 ou 1.0. 
# Se 1.0 falhar por variação de brilho do jogo, use 0.99.
SIMILARITY_EXACT = 0.99 
MAX_WPT_TRIES = 50
MAIN_DELAY = 0.03
WPT_TRY_DELAY = 0.90
WAIT_AFTER_WALK = 0.03
WAIT_AFTER_SPECIAL = 1.5
COMBAT_GRACE = 0.60
SCAN_SLICE = 0.03

screen = Screen()

# --- Pré-carregamento e Cache ---

# 1. Carrega a imagem universal de ataque (busca exata)
# Certifique-se de que o arquivo "atacando.png" esteja na pasta IMG_DIR
PAT_ATACANDO = Pattern("atacando.png").exact() 

# 2. Carrega lista de monstros (apenas imagens de busca/idle)
def load_monsters():
    monsters = []
    try: files = os.listdir(IMG_DIR)
    except: files = []
    for fname in files:
        # Ignora waypoints e a nova imagem universal de ataque
        if not fname.endswith(".png") or fname.startswith("WPT_") or fname == "atacando.png":
            continue
        monsters.append({"name": fname[:-4], "pat": Pattern(fname).similar(SIMILARITY_EXACT)})
    return monsters

MONSTERS = load_monsters()

# 3. Cache de Waypoints
CACHE_WPT = {}
for w in WAYPOINTS:
    id_w = w["wpt"]
    CACHE_WPT[id_w] = Pattern("WPT_%d.png" % id_w).similar(SIMILARITY_EXACT)

# --- Variáveis de Estado ---
last_combat_ts = 0.0
pending_target_name = None
pending_target_match = None
running = True

# --- Funções ---

def mark_combat():
    global last_combat_ts
    last_combat_ts = time.time()

def combat_grace_active():
    return (time.time() - last_combat_ts) < COMBAT_GRACE

def move_mouse_to_center_random():
    cx, cy = screen.getW() / 2, screen.getH() / 2
    dx, dy = random.randint(-15, 15), random.randint(-15, 15)
    mouseMove(Location(int(cx + dx), int(cy + dy)))

def is_attacking():
    # Agora busca apenas pela imagem universal na região de monstros
    if regMonstros.exists(PAT_ATACANDO, 0):
        mark_combat()
        return True
    return False

def find_monster():
    for m in MONSTERS:
        match = regMonstros.exists(m["pat"], 0)
        if match:
            mark_combat()
            return (m["name"], match)
    return (None, None)

def fast_wait_scan(duration):
    global pending_target_name, pending_target_match
    start = time.time()
    while (time.time() - start) < duration:
        if not running or is_attacking(): return True
        name, match = find_monster()
        if match:
            pending_target_name, pending_target_match = name, match
            return True
        wait(SCAN_SLICE)
    return False

def do_wpt_action(mode):
    if not isinstance(mode, basestring): return
    if mode.startswith("talk"):
        start, end = mode.find("("), mode.rfind(")")
        if start != -1 and end != -1:
            parts = [p.strip() for p in mode[start+1:end].split(";") if p.strip()]
            for phrase in parts:
                type(phrase); type(Key.ENTER); wait(0.75)
    elif mode == "rope": click(regRope.getCenter())
    elif mode == "shovel": click(regShovel.getCenter())
    elif mode == "use": rightClick(regUse.getCenter())

def is_special_mode(mode):
    return isinstance(mode, basestring) and (mode.startswith("talk") or mode in ("rope", "shovel", "use"))

def do_cavebot_step(idx, tries, at_wpt, h_mode):
    if not WAYPOINTS: return (idx, tries, at_wpt)
    w = WAYPOINTS[idx]
    wpt_pat = CACHE_WPT[w["wpt"]]
    m = regWpt.exists(wpt_pat, 0.05)

    if h_mode == "explorer":
        if not m:
            if tries == 0: return ((idx + 1) % len(WAYPOINTS), 0, False)
            wait(WAIT_AFTER_SPECIAL if is_special_mode(w["mode"]) else WAIT_AFTER_WALK)
            do_wpt_action(w["mode"])
            return ((idx + 1) % len(WAYPOINTS), 0, False)
        
        click(m); move_mouse_to_center_random()
        if fast_wait_scan(WPT_TRY_DELAY): return (idx, tries + 1, at_wpt)
        if (tries + 1) >= MAX_WPT_TRIES: return ((idx + 1) % len(WAYPOINTS), 0, False)
        return (idx, tries + 1, at_wpt)
    
    if not at_wpt:
        if not m:
            if tries == 0: return ((idx + 1) % len(WAYPOINTS), 0, False)
            wait(WAIT_AFTER_WALK); do_wpt_action(w["mode"])
            return (idx, 0, True)
        click(m); move_mouse_to_center_random()
        if fast_wait_scan(WPT_TRY_DELAY): return (idx, tries + 1, False)
        return (idx, tries + 1, False)
    return ((idx + 1) % len(WAYPOINTS), 0, False)

def stop_script(event):
    global running
    running = False

Env.addHotkey(Key.ESC, KeyModifier.CTRL, stop_script)
print("Cavebot iniciado. CTRL+ESC para parar.")

# --- Loop Principal ---
wasAttacking = False
current_index = 0
tries_for_current = 0
at_current_wpt = False

while running:
    attacking_now = is_attacking()

    if attacking_now:
        wasAttacking = True
        wait(MAIN_DELAY)
        continue 

    if wasAttacking and not attacking_now:
        type(Key.END) # Loot
        wasAttacking = False
        wait(0.1)

    if pending_target_match:
        click(pending_target_match)
        move_mouse_to_center_random()
        pending_target_match = None
        wasAttacking = True
        continue

    can_attack = (HUNT_MODE != "box" or at_current_wpt)
    if can_attack:
        m_name, m_match = find_monster()
        if m_match:
            click(m_match)
            move_mouse_to_center_random()
            wasAttacking = True
            wait(0.1)
            continue

    if not combat_grace_active():
        current_index, tries_for_current, at_current_wpt = do_cavebot_step(
            current_index, tries_for_current, at_current_wpt, HUNT_MODE
        )

    wait(MAIN_DELAY)